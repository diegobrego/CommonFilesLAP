<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Motorradteile</title>
</head>

<body>
    <h1>Motorradteile</h1>
    <nav>
        <ul>
            <li><a href="modelle.php">Modelle</a></li>
            <li><a href="teile.php">Teile</a></li>
        </ul>
    </nav>
</body>
</html>